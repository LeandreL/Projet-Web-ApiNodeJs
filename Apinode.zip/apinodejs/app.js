﻿const express = require('express')
//const morgan = require('morgan')
const mysql = require('mysql')
const bodyParser = require('body-parser')
const app = express()

app.listen(3000, () =>{
  console.log("NODE JS API IS RUNNING ON PORT 3000!")
})

function getSQL(){
  return mysql.createConnection({
    host: 'localhost',
    user: 'root',
    database: 'site'
  })
}

app.use(bodyParser.urlencoded({extended: false}))
//app.use(morgan('short'))

app.get("/", (req, res) => {
  console.log("Responding to ping request")
  res.send("NODE.JS SERVER UP AND RUNNING")
})

app.get("/api/users/:param", (req, res) => {

  const connection = getSQL()
  var param = req.params.param
  if(param.includes("@")){
    var queryString = "SELECT * FROM users WHERE Email = ?"
    connection.query(queryString, [req.params.param], (err, rows, fields) => {
      if(err){
        console.log("Erreur: " + err)
        res.sendStatus(500)
        return
      }
      console.log("User Email: "+req.params.param+" published(it may not exist thought)")
      connection.end()
      res.json(rows)
    })
  }else{
      var queryString = "SELECT * FROM users WHERE ID = ?"
      connection.query(queryString, [req.params.param], (err, rows, fields) => {
        if(err){
          console.log("Erreur: " + err)
          res.sendStatus(500)
          return
        }
        console.log("User ID: "+req.params.param+" published(it may not exist thought)")
        connection.end()
        res.json(rows)
      })
    }
})

app.get("/api/users", (req, res) => {

  const connection = getSQL()

  var queryString = "SELECT * FROM users"
  connection.query(queryString, (err, rows, fields) => {
    if(err){
      console.log("Erreur: " + err)
      res.sendStatus(500)
      return
    }
    console.log("Full user list published")
    connection.end()
    res.json(rows)
  })
})


//POST API
app.post("/api/users", (req , res) => {

    const connection = getSQL()

    var queryString = "INSERT INTO users (username, email, password, user_campus, role,) VALUES (?,?,?,?,?)"
    connection.query(queryString, [req.body.username, req.body.email, req.body.password, req.body.user_campus, req.body.role], (err, results) => {
      if(err){
        console.log("Echec de l'insertion")
        res.sendStatus(500)
        return
      }
      console.log("Success with INSERT")
      connection.end()
      res.send("Success")
      //res.end()
    })
})

// DELETE API
 app.delete("/api/users/:id", function(req , res){

      const connection = getSQL()

      var queryString = "DELETE FROM users WHERE ID = ?";
      connection.query(queryString, [req.params.id], (err, rows, fields) => {
        if(err){
          console.log("Erreur: " + err)
          res.sendStatus(500)
          return
        }
        console.log("Success with DELETE")
        connection.end()
        res.send("Success")
        //res.end()
      })
})

//PUT API
 app.put("/api/users/:id", function(req , res){

        const connection = getSQL()

        var queryString = "UPDATE users SET email = ? , password = ? , user_campus = ? , role = ? , WHERE (ID = ?)"
        connection.query(queryString, [req.body.email, req.body.password, req.body.user_campus, req.body.role], (err, results) => {
          if(err){
            console.log("Echec de la modification")
            res.sendStatus(500)
            return
          }
          console.log("Success with UPDATE")
          connection.end()
          res.send("Success")
          //res.end()
          })
});
